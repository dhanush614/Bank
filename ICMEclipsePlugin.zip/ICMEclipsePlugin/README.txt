==========================================================================================
Eclipse Plug-in for Custom Widget/Action and Custom Editor Development in IBM Case Manager
==========================================================================================

Copyright information:
https://www.ibm.com/developerworks/community/terms/download?lang=en

Author:
Yoshiroh Kamiyama, IBM

This eclipse plug-in is for quickly building up an ICM custom widget/action or custom editor project in minutes.
It allows you to create the following two types of projects by a wizard.

- Custom Page Widget/Action Project
- Custom Editor Project

A created custom page widget/action should work on either ICM 5.2.0 or 5.2.1.
However, a custom editor works only on 5.2.1, since custom editor for the properties view
is a new feature introduced in 5.2.1.

Installation
------------
- Copy com.ibm.tsdl.icm.ui_*.jar to the dropins folder of your Eclipse (Juno, Kepler, or Luna).
- Restart Eclipse

Usage
-----
- Select [File]-[New]-[Project].
- In the [Select a wizard] dialog box, open the [ICM] node and select either
  [ICM 5.2 Custom Page Widget Project] or [ICM 5.2.1 Custom Editor Project].
- Follow the wizard instructions. In either project type, you must specify the location of navigatorAPI.jar.

Description
-----------
With the wizard, you can choose whether to use a separate web project or to use only an ICN plug-in project.
You can configure custom properties, custom events, and custom actions.
Also, you can configure ICN plug-in configuration panel.

All the wizard pages have sample values as default values.
You can leave them as they are (except the location of navigatorAPI.jar), if you would like to create
a hello world plug-in.

The location of navigatorAPI.jar is a required field. On Windows, it is typically located at
C:\Program Files (x86)\IBM\ECMClient\lib\navigatorAPI.jar
You cannot finish the wizard without specifying the location since it is necessary for building the project.

The ICM eclipse plug-in generates a working ICM plugin code. After you complete the wizard, without any modifications,
you should be able to build the project by running build.xml with Ant, and the built ICM plug-in should work.
For example, if you configure event subscribers with the wizard, the resulting code will be a widget
that simply displays subscribed values. This gives you information on how to get the subscribed values,
how to display something on the widget, etc.

References
----------
Custom Page Widget:
- https://ibm.biz/BdEzTE (Creating custom widgets with the IBM Case Manager JavaScript API)

Custom Editor:
- https://ibm.biz/BdEzTX (Customizing Properties View in IBM Case Manager v5.2.1)
